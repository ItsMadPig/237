Group Members:
Aaron Hsu (ahsu1)
Neil Batlivala (nbatliva)

Brief overview of project:
The main loop of the game is found in PhysicsEngine and continuosly updates the state of the level and player and then draws them.
There are 3 main objects: Player, Item, and Level
Player defines the player.
Item is the base for creating any item in the game from keys to boulders
Level instantiates each level. We created functions to create platforms, gates, etc. and thus creating more levels is quick. The current levels demonstrate the various objects we have created for the game.

Locking/Unlocking godMode: There is a variable called godMode at the top of Main.js. Set this to true to never die.

This project demonstrates almost all of the canvas and context including the following:
- various levels of scope
- all the built in types
- different loops
- multiple ways to work with canvas and context, including translating and rotating
- writing text onto context
- using keyboard events
- using spritesheets
- setting intervals and timers
- arrays and corresponding forEach function
- math methods
- extensive work with objects
- writing functions
