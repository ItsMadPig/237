Aaron Hsu
ahsu1@andrew.cmu.edu

I've tested all my tests on iPhone 5 version 6.1.2 with Safari because after updating to the newest chrome on my iphone everything became buggy.


