/* Aaron Hsu (ahsu1)
 * ahsu1@andrew.cmu.edu
 * Srinivasan (srinivav)
 * srinivav@andrew.cmu.edu
*/
$(document).ready(function() {

	$("#instButton").click(function(event) {
			$(this).children("#inst").slideToggle();
	});

	$("#creditsButton").click(function(event) {
		$(this).children("#cred").slideToggle();
	})
	
});