﻿Jingyi Feng, jingyif (jingyif@cmu.edu)
Aaron Hsu, ahsu1(ahsu1@andrew.cmu.edu)



	Our project idea is to create a free app that makes it easier for passengers to call for a cab, and allows taxi drivers to not pay percentages of their earning to apps such as taxi magic. The app would allow drivers to send their location to the server, so passengers would know where all the drivers are at. Allowing the procedure to be more efficient.

	We've implemented a signup and login feature through passport local. We store all the account information in mongoDb, which allow a more secure and efficient way of storage.
	There are two user interfaces, one for the passenger and one for the driver.
	
	The app for passengers allows them to request a cab with very simple hand motions. The user is able to either type in the address, or drag the marker to the target locations. As the user drags the marker, the address in the bar changes as well. The user can also choose the time either now or the future and the driver if he or she desires to.
	Once the user requests for a cab, it sends a signal to the server and assigns the passenger the closest cab if the user hasn't specified. It then shows the estimated time of arrival for the cab, and draws out the route.
	In order to test out the app, unzip the folder and type node app.js on the terminal. Then on a browser, enter the url http://localhost:8888/index.html.
