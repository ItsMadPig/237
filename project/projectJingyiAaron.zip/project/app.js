//Server main App file
var express = require('express')
    , routes = require('./routes')
    , User = require('./routes/user')
    , http = require('http')
    , fs = require('fs')
    , path = require('path')
    , flash = require('connect-flash')
    //mongodb//
    , mongo = require('mongodb')
    , Db = require('mongodb').Db,
    MongoClient = require('mongodb').MongoClient,
    Server = require('mongodb').Server,
    ReplSetServers = require('mongodb').ReplSetServers,
    ObjectID = require('mongodb').ObjectID,
    Binary = require('mongodb').Binary,
    GridStore = require('mongodb').GridStore,
    Grid = require('mongodb').Grid,
    Code = require('mongodb').Code,
    BSON = require('mongodb').pure().BSON,
    assert = require('assert')
    //passport
    , passport = require('passport')
    , LocalStrategy = require('passport-local').Strategy;



/////////////////////////////
///MONGODB
/////////////////////////////
var host = 'localhost';
var port = mongo.Connection.DEFAULT_PORT;
var optionsWithEnableWriteAccess = {w:1};

// Set up the connection to the local db
var mongoclient = new MongoClient(new Server(
    "localhost", 27017, {native_parser: true}));



// Open the connection to the server
mongoclient.open(function(err, mongoclient) {
  // Get the first db and do an update document on it
  db = mongoclient.db("test");
  console.log("db initiated");
  staticAccount = db.collection("staticAccount");
  deltaPassenger = db.collection("deltaPassenger");
  deltaDriver = db.collection("deltaDriver");
  currentOrders = db.collection("currentOrders");

  //Close the connection
  //mongoclient.close();
});



//////////////
///SETUP
//////////////
var app = express();
app.use(express.static(path.join(__dirname, '/static/passenger')));

app.configure(function(){
    app.set('views', __dirname + '/views');
    app.set('view engine', 'jade');
    app.use(express.favicon());
    app.use(express.logger('dev'));
    app.use(express.cookieParser());
    app.use(express.bodyParser());
    app.use(express.methodOverride());
    app.use(express.session({ secret: 'hot rod' }));
    app.use(flash());
    app.use(passport.initialize());
    app.use(passport.session());

    app.use(app.router);
    app.use(express.static(path.join(__dirname, '/public')));
});

app.configure('development', function(){
    app.use(express.errorHandler());
});



/////////////////////////////
// PASSPORT
/////////////////////////////

function findById(id, fn) {
  staticAccount.find({"_id" : ObjectID(id)}).nextObject(function(err,docs){
    if (docs!== null){
      fn(null,docs);
    }else{
      fn(new Error('User ' + id + ' does not exist'));
    }
  })
}

function findByUsername(username, fn) {

  staticAccount.find({"username": username }).nextObject(function(err, docs){
  if (docs !== null){
    return fn(null, docs);
  }
    return fn(null, null);
  });

}

app.post('/login', function(req, res, next) {
  passport.authenticate('local', function(err, user, info) {
    if (err) { return next(err) }
    console.log(user);
    if (!user) {
      //if no username given
      return res.send({ success : false, message : 'authentication failed' });
    }

    req.logIn(user, function(err) {
      console.log("no error!");
      return res.send({ success : true, user: user, message : 'authentication succeeded' });
    });
  })(req, res, next);
});

app.get('/deserialize', function(req, res, next) {
  passport.authenticate('local', function(err, user, info) {
      return res.send({ success : false, message : 'authentication failed' });
  })(req, res, next);
})


passport.use(new LocalStrategy(
  function(username, password, done) {
    process.nextTick(function(){

      findByUsername(username, function (err, profile) {
      if (err) {
        console.log("error!");
        return done(err); }
      if (!profile) {
        console.log("unknown username");
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (profile.password != password) {
        console.log("wrong password");
        return done(null, false, { message: 'Incorrect password.' });
      }
      console.log("login success!");    
      return done(null, profile);
      });
    })
  }
));

passport.serializeUser(function(user, done) {
  console.log("serialized user!");
  done(null, user._id);

});

passport.deserializeUser(function(user, done) {
  findById(user, function (err, user) {
    console.log("deserialized user!");
    done(err, user);
  });
});



/////////////////////////////
// SOCKET.IO
/////////////////////////////
var io = require('socket.io').listen(8989);


io.sockets.on('connection', function(socket) {
//Inits
socket.emit('init', {success: 'true'});
socket.on('checkID', function(data){
  //Calls
  console.log(data.username + "connected");
    staticAccount.find({"username" : data.username}).nextObject(function(err,docs){
      if ((docs.type)=== "passenger"){
        console.log("turns out I'm a passenger");
        //if I'm a passenger
        deltaDriver.find().toArray(function(err,docs){
            socket.emit('rqDrLos', docs);
          });
      }else{
        //if I'm a driver
        deltaDriver.insert(data, function(err){
          if (err){
            done(err);
          } return;
        });
        console.log("turns out I'm a driver");
        //driverPoll(socket);
      }
      /*socket.on('disconnect',function(data){
        deltaDriver.remove(query, function logResult(error, numberDocsRemoved){
            if (error)
                throw error;
            console.log(numberDocsRemoved)
        });*/
      //})

    })
})
})

//polling so driver keeps updating its location on the database
function driverPoll(socket){
  socket.emit('sndDrInfo', {success: 'true'})
  socket.on('sndDrInfoCB',function(data){
    var item = {$set:{ lat: data.lat, lon: data.lon}};
      ////////////check if same, if same then dont update
      deltaDriver.find({username:data.username}).nextObject(function(err,result){
             console.log(data.lon===result.lon);
             console.log(data.lat===result.lat);
             console.log(data.username === result.username);
            if ((data.username === result.username) && (data.lon === result.lon) &&
                (data.lat === result.lat)){

                driverPoll(socket);
            }else{ deltaDriver.update({username:data.username}, item, function checkError(error){
                if (error){
                  throw error;
                } else {
                  driverPoll(socket);
                }
              })
        
            
            }
        })
      })
}




/////////////////////////////
// GET
/////////////////////////////
/*app.get('/views/driver/index', function(req, res){
    res.sendfile('static/driver/index.html');
});

app.get('/views/passenger/index', function(req, res){
    res.sendfile('static/passenger/index.html');
})

app.get('/', function(req, res){
  res.render('index', { user: req.user });
});

app.get('/account', ensureAuthenticated, function(req, res){
  res.render('account', { user: req.user });
});

app.get('/login', function(req, res){
  res.render('login', { user: req.user, message: req.flash('error') });
});

app.get('/logout', function(req, res){
  req.logout();
  res.redirect('/login.html');
});*/



//receives signup information
app.post("/signup", function(request, response) {
  var item = [{"username": request.body.username,
              "email": request.body.email,
              "tel": request.body.tel,
              "password": request.body.password,
              "type": request.body.type
             }];

    staticAccount.insert(item,function(err, result) {
        response.send({
          item: item,
          success: true
        });
    });
});

function calculateTime(driver){
  if (driver === "driver"){
    return 5;
  }else if (driver === "driver2"){
    return 8;
  }
}
///////////////////////////////////////////////////////////////////////////////////
//receives request information
app.post("/requestPickup", function(request, response){
  var time = calculateTime(request.body.driver);
  var pickup = request.body.pickup;
  var dropoff = request.body.dropoff;
  var driver = request.body.driver;
  var passenger = request.body.passenger;
  var requestedTime = request.body.requestedTime;
  var item = {"pickup": pickup,
    "dropoff": dropoff,
    "driver": driver,
    "passenger": passenger,
    "requestedTime": requestedTime,
    "time": time}
  currentOrders.insert(item, function(err, result){

    response.send({
      item: item,
      success: true
    })
  })
  //auto assign driver, date, push to currentOrders database
})
/*
app.post("/availability",function(req,res){
  var avail = req.body.avail;
  var username = req.body.username;
  var lat = req.body.lat;
  var lon = req.body.lon;
  if (avail){
    
  }else{
    deltaDriver.remove()
  }
}*/




app.listen(8888);


function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) { return next(); }
  res.redirect('/index.html')
}

